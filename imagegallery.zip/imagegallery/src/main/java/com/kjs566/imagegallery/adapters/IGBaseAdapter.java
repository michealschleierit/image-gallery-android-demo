package com.kjs566.imagegallery.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import android.support.v7.graphics.Palette;

import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;

import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.request.RequestOptions;
//import com.kjs566.imagegallery.GlideApp;
import com.kjs566.imagegallery.GlideLoadable;
import com.kjs566.imagegallery.R;
import com.kjs566.imagegallery.ui.IGDetailItemViewHolder;

import java.util.Random;

public abstract class IGBaseAdapter extends RecyclerView.Adapter<IGDetailItemViewHolder> implements Palette.PaletteAsyncListener{
    private final RequestOptions mRequestOptions;
    private AsyncTask paletteTask;
    private Bitmap bitmap;

    private boolean hasPalette;
    private int colorLightMuted;
    private int colorDarkMuted;
    private int colorVibrant;
    Context context;

    IGDetailItemViewHolder current_holder;

    public IGBaseAdapter(RequestOptions requestOptions){
        this.mRequestOptions = requestOptions;
    }

    @NonNull
    @Override
    public IGDetailItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        return new IGDetailItemViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.ig_detail_item, parent, false));
    }

    @Override
    public void onBindViewHolder(final @NonNull IGDetailItemViewHolder holder, int position) {
        //generate a random integer/number between 1 and 1000 java
        int random_number = (new Random()).nextInt(1000 - 1) + 1;
        current_holder = holder;
        Picasso.get()
                .load("https://aro-micheal.herokuapp.com/avatar/?h=1000&w=300&id=" + (position + 50))
                .into(new Target() {
                    @Override public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                        IGBaseAdapter.this.bitmap = bitmap;
                        holder.getImageView().setImageBitmap(bitmap);
                        paletteTask = new Palette.Builder(bitmap)
                                .maximumColorCount(32)
                                .generate(IGBaseAdapter.this);
                    }

                    @Override
                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {

                    }

                    @Override public void onPrepareLoad(Drawable placeHolderDrawable) {

                    }
                });
    }

    private void cancelPaletteTask() {
        if (paletteTask != null) {
            paletteTask.cancel(true);
            paletteTask = null;
        }
    }

    @Override
    public void onGenerated(Palette palette) {
        hasPalette = true;
        int black = context.getResources().getColor(android.R.color.black);
        int white = context.getResources().getColor(android.R.color.white);
        colorDarkMuted = palette.getDarkMutedColor(black);
        colorVibrant = palette.getVibrantColor(white);
        colorLightMuted = palette.getLightMutedColor(white);

        int red = Color.red(colorDarkMuted);
        int green = Color.green(colorDarkMuted);
        int blue = Color.blue(colorDarkMuted);

        if(current_holder !=null){
            current_holder.getImageView().setBackgroundColor(Color.argb( 0xE5,  red, green, blue));
            //  context.getResources().getInteger(R.integer.gallery_info_bg_alpha),
            //    title.setTextColor(colorVibrant);
            //    description.setTextColor(colorLightMuted);
        }
    }

    public abstract GlideLoadable createGlideLoadable(int itemPosition);

}
