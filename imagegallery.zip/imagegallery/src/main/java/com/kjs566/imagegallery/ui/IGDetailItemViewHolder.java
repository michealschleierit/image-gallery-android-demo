package com.kjs566.imagegallery.ui;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.kjs566.imagegallery.R;

public class IGDetailItemViewHolder extends RecyclerView.ViewHolder{
    private ImageView mImageView;
    public View img_root_bg;

    public IGDetailItemViewHolder(View itemView) {
        super(itemView);
        mImageView = itemView.findViewById(R.id.ig_iv_image);
        img_root_bg = itemView.findViewById(R.id.img_root_bg);
    }

    public ImageView getImageView() {
        return mImageView;
    }
}
