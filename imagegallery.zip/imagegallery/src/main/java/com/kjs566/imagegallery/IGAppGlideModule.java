package com.kjs566.imagegallery;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public class IGAppGlideModule extends AppGlideModule{ }
